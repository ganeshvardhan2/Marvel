package org.wipro.Mobileapplication;

public class Sharath implements Sim{
    @Override
    public void calling() {
        System.out.println("calling from sharath");
    }

    @Override
    public void data() {
        System.out.println("data from sharath");

    }
}
