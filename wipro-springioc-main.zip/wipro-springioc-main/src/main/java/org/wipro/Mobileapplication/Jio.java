package org.wipro.Mobileapplication;

public class Jio implements Sim{
    @Override
    public void calling() {
        System.out.println("calling using jio sim");

    }

    @Override
    public void data() {
        System.out.println("browsing internet using jio sim");

    }
}
