package org.wipro.Mobileapplication;

public interface Sim {
    void calling();
    void data();
}
