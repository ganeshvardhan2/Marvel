package org.wipro.Mobileapplication;

public class Vi implements Sim{
    @Override
    public void calling() {
        System.out.println("calling using vi");

    }

    @Override
    public void data() {
        System.out.println("data using vi");

    }
}
